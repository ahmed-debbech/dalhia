package tn.dalhia.entities.enumerations;

public enum Satisfaction {
    EXCELLENT,
    GOOD,
    MODERATE,
    UNSATISFIED
}
