package tn.dalhia.entities.enumerations;

public enum VoteType {
    UPVOTE,
    DOWNVOTE
}
