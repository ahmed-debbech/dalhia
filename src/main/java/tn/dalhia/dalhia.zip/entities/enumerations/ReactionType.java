package tn.dalhia.entities.enumerations;

public enum ReactionType {
    WOW,
    CRYING,
    ANGRY,
    LOVE,
    CARE,
    HAHA
}
