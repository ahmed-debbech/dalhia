package tn.dalhia.entities.enumerations;

public enum Access {
    PUBLIC, PRIVATE
}
