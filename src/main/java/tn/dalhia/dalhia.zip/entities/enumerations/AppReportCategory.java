package tn.dalhia.entities.enumerations;

public enum AppReportCategory {
Harassment, Aggression, Discomfort, Other 
}