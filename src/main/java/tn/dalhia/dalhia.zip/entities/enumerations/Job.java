package tn.dalhia.entities.enumerations;

public enum Job {
    PSY,
    DOCTOR,
    LAWYER,
    COACH
}
