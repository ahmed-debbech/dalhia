package tn.dalhia.entities.enumerations;

public enum Tag {
    QUESTION,
    DISCUSSION,
    HELP,
    IDEA,
    OPINION
}
