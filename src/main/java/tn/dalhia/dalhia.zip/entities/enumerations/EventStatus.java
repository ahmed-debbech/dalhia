package tn.dalhia.entities.enumerations;

public enum EventStatus {
    SCHEDULED,
    CONFIRMED,
    DONE,
    IN_PROGRESS
}
