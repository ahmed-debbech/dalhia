package tn.dalhia.entities.enumerations;

public enum ResourceType {
    IMAGE, AUDIO, TEXT, VIDEO
}
