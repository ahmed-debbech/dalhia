package tn.dalhia.entities.enumerations;

public enum ReportCategory {
    VIOLENCE, ABUSE, OTHER
}
