package tn.dalhia.entities.enumerations;

public enum ReportStatus {
    CONFIRMED, DECLINED, PENDING
}
