package tn.dalhia.entities.enumerations;

public enum EventCategory {
    DAYCCARE,
    OTHER
}
