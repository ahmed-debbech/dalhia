package tn.dalhia.entities.enumerations;

public enum TopicClaimType {
    REDUNDANT,
    OFFENSIVE,
    OFF_TOPIC
}
