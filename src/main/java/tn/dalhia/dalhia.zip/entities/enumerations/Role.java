package tn.dalhia.entities.enumerations;

public enum Role {
    EXPERT, //can be also a COACH
    WOMAN,
    ADMIN,
    ASSOCIATION
}
