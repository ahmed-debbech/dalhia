package tn.dalhia.entities.enumerations;

public enum RequestStatus {
    APPROVED, PENDING, DECLINED
}
