package tn.dalhia.entities.enumerations;

public enum CertificateType {
    PROFESSIONAL, HOBBY
}
