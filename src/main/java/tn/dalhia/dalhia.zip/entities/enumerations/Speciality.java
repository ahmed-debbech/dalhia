package tn.dalhia.entities.enumerations;


public enum Speciality {
    TAILOR,
    HEALTH,
    LANGUAGES,
    COOKING
}
