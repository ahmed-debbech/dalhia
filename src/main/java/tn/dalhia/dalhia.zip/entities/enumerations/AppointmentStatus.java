package tn.dalhia.entities.enumerations;

public enum AppointmentStatus {
    CONFIRMED, DECLINED, PENDING, CANCELLED
}
