package tn.dalhia.entities.enumerations;

public enum CourseStatus {
    ACCEPTED, REJECTED
}
