package tn.dalhia.entities.enumerations;

public enum ChannelType {
    GROUP,
    INDIV
}
